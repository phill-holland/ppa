#include "net/socket/interface/socket.h"
#include "net/socket/interface/client.h"
#include "net/stream/interface/out.h"
#include "core/threading/semaphore.h"
#include "core/debug/logger.h"

#ifndef _NET_STREAM_WSBUFFER_OUT
#define _NET_STREAM_WSBUFFER_OUT

namespace net
{
    namespace stream
    {
        namespace wsbuffer
        {
            class out : public net::stream::interface::out
            {
                static const long LENGTH = 10000L;

            private:
                char *buffer;
                long writeptr;
                long length;                        

                net::socket::interface::client *client;

                core::threading::semaphore::token token;

                bool init;

            public:
                out(net::socket::interface::client *destination, long length = LENGTH) { makeNull(); reset(destination, length); }
                ~out() { cleanup(); }

                bool initalised() { return init; }
                void reset(net::socket::interface::client *destination, long length);

                int write(string data);

                bool flush();

                void clear()
                {
                    core::threading::semaphore lock(token);
                    
                    writeptr = 0L;
                }

                bool terminate() { return true; }

            protected:
                bool send();
                
            protected:
                void makeNull()
                {
                    buffer = NULL;
                }

                void cleanup()
                {
                    if(buffer != NULL) delete[] buffer;
                }
            };
        };
    };
};

#endif