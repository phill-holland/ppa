#include "core/string/string.h"

#ifndef _HET_HTTP_SOCKET_INTERFACE_CLIENT
#define _HET_HTTP_SOCKET_INTERFACE_CLIENT

namespace net
{
    namespace socket
    {
        namespace interface
        {
            class client
            {
            public:
                virtual bool open(string &source, long port) = 0;
                virtual bool isopen() = 0;

                virtual int read(char *buffer, int length, int flags) = 0;

                virtual int write(string &data, int flags) = 0;
                virtual int write(const char *buffer, int length, int flags) = 0;

                virtual void close() = 0;
            };
        };
    };
};

#endif