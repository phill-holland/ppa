#include "net/http/interface/header.h"
#include "net/stream/interface/in.h"
#include "net/stream/interface/out.h"
#include "core/string/string.h"

#ifndef _NET_HTTP_REQUEST
#define _NET_HTTP_REQUEST

namespace net
{
	namespace http
	{
		namespace request
		{
			class header : public ::net::http::interface::header
			{
			public:
				string type;
				string path;
				string protocol;

			public:
				header() : ::net::http::interface::header() 
				{ 
					clear(); 
				}

			public:
				void clear();
				bool isempty();
				
				bool isGet();
				bool isPost();

			public:
				string request();

			protected:
				int extract(const string &value);
			};

			class client : public ::net::http::interface::client
			{
			public:
				header head;

			public:
				client() { clear(); }

			public:
				void clear() { head.clear(); }
				
				bool decode(::net::stream::interface::in *source)
				{
					return ::net::http::interface::client::decode(&head, source) && !head.isempty();
				}

				bool request(::net::stream::interface::out *destination);
			};
		};
	};
};

#endif