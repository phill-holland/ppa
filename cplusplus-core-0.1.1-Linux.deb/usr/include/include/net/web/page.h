#include "core/string/string.h"
#include "parameter.h"
#include "parameters.h"
#include "authentication.h"
#include "address.h"

#ifndef _NET_WEB_PAGE
#define _NET_WEB_PAGE

namespace net
{
	namespace web
	{
		class client;
	};
};

namespace net
{
	namespace web
	{
		class page
		{
			friend class net::web::client;

			string *body;

			const static long length = 32768L;
			web::parameters parameters;
			bool init;

		public:
			authentication authorization;

		public:
			long status;
			long port;

		public:
			string url;
			string redirect;

		public:
			page() { makeNull(); reset(); }
			page(string &addr) { makeNull(); url.copy(addr); reset(); }
			~page() { cleanup(); }

			bool initalised() { return init; }

			void reset();

			void clear();

			bool set(string name, string value);
			string get(string name);

			void data(string &source) { *body = source; }
			string data() { return *body; }

			long size() { return (long)body->size(); }

			bool isempty();

		protected:
			void makeNull();
			void cleanup();
		};
	};
};

#endif