#ifndef _CORE_ERROR_INTERFACE
#define _CORE_ERROR_INTERFACE

namespace core
{
    namespace error
    {
        namespace interface
        {
            class error
            {
            public:
                virtual bool isError() = 0;
                virtual void makeError(long code) = 0;
                virtual void resetError() = 0;
                virtual long lastError() = 0;
            };
        };
    };
};

#endif