#include <sql.h>
#include <sqlext.h>
#include "core/string/string.h"
#include "core/custom/guid.h"
#include "core/database/interface/recordset.h"

#ifndef _CORE_DATABASE_RECORDSET
#define _CORE_DATABASE_RECORDSET

namespace core
{
	namespace database
	{
		class connection;

		class recordset : public core::database::interface::recordset
		{
			friend class connection;

			SQLHANDLE lpStatement;

		private:
			bool create(void *source);

		public:
			recordset() { lpStatement = NULL; }
			~recordset() { cleanup(); }

			bool IsInitalised() { return lpStatement != NULL; }

			bool MoveNext();

			long GetLong(long index);
			string GetString(long index);
			float GetFloat(long index);
			double GetDouble(long index);
			bool GetBool(long index);
			TIMESTAMP_STRUCT GetTimeStamp(long index);
			core::custom::guid GetGUID(long index);

			bool BindLong(long index, long &data);
			bool BindString(long index, SQLCHAR *data);
			bool BindFloat(long index, float &data);
			bool BindDouble(long index, double &data);
			bool BindBool(long index, bool &data);
			bool BindTimeStamp(long index, TIMESTAMP_STRUCT &data);
			bool BindGUID(long index, core::custom::guid &data);

			bool BindLongColumn(long index, int *source, long length);
			bool BindFloatColumn(long index, float *source, long length);

			bool Execute();

			void close() { cleanup(); }

			string getStatementError();

		protected:
			bool Execute(string sql);
			bool Prepare(string sql);

		protected:
			void cleanup();

		public:
			recordset operator=(const recordset &src)
			{
				cleanup(); lpStatement = src.lpStatement;
				return *this;
			}
		};
    };
};

#endif