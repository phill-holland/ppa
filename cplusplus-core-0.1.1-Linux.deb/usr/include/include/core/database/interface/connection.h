#include "core/string/string.h"

#if !defined(_CORE_DATABASE_INTERFACE_CONNECTION)
#define _CORE_DATABASE_INTERFACE_CONNECTION

namespace core
{
    namespace database
    {
        namespace interface
        {
            class recordset;

            class connection
            {
            public:
                virtual bool initalised() = 0;

                virtual bool open(string connection) = 0;
                virtual bool open(const char *connection) = 0;

                virtual bool close() = 0;

                virtual bool executeNoResults(string sql) = 0;
                virtual bool executeWithResults(string sql, recordset *result) = 0;
                virtual long executeScalar(string sql) = 0;
                virtual bool Prepare(string sql, recordset *result) = 0;
            };	
        };
    };
};

#endif