#include "core/database/interface/recordset.h"

#if !defined(_DATABASE_INTERFACE_FACTORY_RECORDSET)
#define _DATABASE_INTERFACE_FACTORY_RECORDSET

namespace core
{
    namespace database
    {	
        namespace interface
        {
            namespace factory
            {
                class recordset
                {
                public:
                    virtual database::interface::recordset *get() = 0;
                };
            };
        };
    };
};

#endif