#include <vector>
#include "core/database/interface/factory/recordset.h"
#include "core/database/interface/recordset.h"
#include "core/database/recordset.h"

#if !defined(_CORE_DATABASE_FACTORY_RECORDSET)
#define _CORE_DATABASE_FACTORY_RECORDSET

namespace core
{
    namespace database
    {
        namespace factory
        {
            class recordset : public core::database::interface::factory::recordset
			{
				std::vector<database::interface::recordset*> recordsets;

				bool init;

			public:
				recordset() { makeNull(); reset(); }
				~recordset() { cleanup(); }

				bool initalised() { return init; }
				void reset()
				{
					init = false; cleanup();

					init = true;
				}

				database::recordset *get()
				{
					database::recordset *result = new core::database::recordset();
					if(result != NULL)
					{
						recordsets.push_back(result);
					}

					return result;
				}

			protected:
				void makeNull() { }
				void cleanup()
                {
                    try
                    {
                        if(recordsets.size() > 0)
                        {
                            for(int i = recordsets.size(); i >= 0; --i)
                            {
                                delete recordsets[i];
                            }
                        }
                    } catch(...) { }
                }
			};
        };
    };
};

#endif
