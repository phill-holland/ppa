#include "core/threading/semaphore.h"
#include "core/threading/thread.h"
#include "core/queue/fifo.h"
#include "core/string/string.h"
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <chrono>

#ifndef _CORE_DEBUG_DEBUGGER
#define _CORE_DEBUG_DEBUGGER

namespace core
{
    namespace debug
    {
        class debugger : public core::threading::thread
        {
            const static long MINUTES = 2L;
            const static long QUEUE = 4096L;
            const static long BUFFER = 500L;

            core::queue::fifo<string, QUEUE> *data;

            string filename;

            std::chrono::high_resolution_clock::time_point clock;

            core::threading::semaphore::token token;

            int minutes;

            bool init;

        public:
            void background(core::threading::thread *bt);

        public:
            debugger() { makeNull(); reset(string("debug.txt")); }
            debugger(string filename) { makeNull(); reset(filename); }
            ~debugger() { cleanup(); }

            void reset(string filename);
            bool initalised() { return init; }

            bool push(string source, bool timestamp = true);
            bool push(float source);
            bool push(long source);
            bool push(int source);
            bool push(bool value);

        protected:
            void flush();

        protected:
            void floatToStr(char *temp, float number);
            void intToStr(char *temp, int number);
            void longToStr(char *temp, long number);
            void longHexToStr(char *temp, long number);
            void boolToStr(char *temp, bool value);

        protected:
            void makeNull();
            void cleanup();
        };
    };
};

extern core::debug::debugger Debugger;

#endif
