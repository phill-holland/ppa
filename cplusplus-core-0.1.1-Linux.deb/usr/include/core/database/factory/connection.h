#include <vector>
#include "core/database/interface/factory/connection.h"
#include "core/database/interface/connection.h"
#include "core/database/connection.h"

#if !defined(_CORE_DATABASE_FACTORY_CONNECTION)
#define _CORE_DATABASE_FACTORY_CONNECTION

namespace core
{
	namespace database
	{
		namespace factory
		{
			class connection : public core::database::interface::factory::connection
			{
				std::vector<interface::connection*> connections;

				bool init;

			public:
				connection() { makeNull(); reset(); }
				~connection() { cleanup(); }

				bool initalised() { return init; }
				void reset()
				{
					init = false; cleanup();

					connections.clear();

					init = true;
				}

				interface::connection *get()
				{
					database::connection *result = new core::database::connection();
					if(result != NULL)
					{
						connections.push_back(result);
					}

					return result;
				}

			protected:
				void makeNull() { }
				void cleanup()
                {
                    try
                    {
                        if(connections.size() > 0)
                        {
                            for(int i = connections.size(); i >= 0; --i)
                            {
                                delete connections[i];
                            }
                        }
                    } catch(...) { }
                }
			};
        };
    };
};

#endif

