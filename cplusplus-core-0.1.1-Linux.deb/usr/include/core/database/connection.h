#include <sql.h>
#include <sqlext.h>
#include "core/string/string.h"
#include "core/database/interface/connection.h"
#include "core/database/recordset.h"

#ifndef _CORE_DATABASE_CONNECTION
#define _CORE_DATABASE_CONNECTION

namespace core
{
	namespace database
	{
		class connection : public core::database::interface::connection
		{
			SQLHANDLE lpEnvironment;
			SQLHANDLE lpConnection;

			bool init, isopen;

		public:
			connection() { makeNull(); reset(); };
			~connection() { cleanup(); }

			bool initalised() { return init; }

			void reset();

			bool open(string connection);
			bool open(const char *connection);

			bool close();

			bool executeNoResults(string sql);
			bool executeNoResults(string sql, string &error);

			bool executeWithResults(string sql, core::database::interface::recordset *result);
			long executeScalar(string sql);
			bool Prepare(string sql, core::database::interface::recordset *result);

			string getConnectionError();

		protected:
			void makeNull();
			void cleanup();
		};
	};
};

#endif