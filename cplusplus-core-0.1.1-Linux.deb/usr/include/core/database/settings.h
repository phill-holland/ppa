#include "core/string/string.h"
#include "core/database/interface/factory/connection.h"
#include "core/database/interface/factory/recordset.h"

#if !defined(_CORE_DATABASE_SETTINGS)
#define _CORE_DATABASE_SETTINGS

namespace core
{
	namespace database
	{	
		using namespace core::database::interface;
		
		class settings
		{
			factory::connection *connections;
			factory::recordset *recordsets;

			string location;

			bool init;

		public:
			settings(string location, factory::connection *connections, factory::recordset *recordsets) { makeNull(); reset(location, connections, recordsets); }

			bool initalised() { return init; }

			void reset(string location, factory::connection *connections, factory::recordset *recordsets)
			{
				init = false;

				this->location = location;
				this->connections = connections;
				this->recordsets = recordsets;

				init = true;
			}

			string getLocation() { return location; }

			factory::connection *getConnections() { return connections; }
			factory::recordset *getRecordSets() { return recordsets; }

		protected:
			void makeNull()
			{
				connections = NULL;
				recordsets = NULL;
			}
		};
	};
};

#endif