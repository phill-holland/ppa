#include "core/database/interface/recordset.h"

#if !defined(_DATABASE_INTERFACE_FACTORY_CONNECTION)
#define _DATABASE_INTERFACE_FACTORY_CONNECTION

namespace core
{
    namespace database
    {	
        namespace interface
        {
            namespace factory
            {
                class connection
                {
                public:
                    virtual database::interface::connection *get() = 0;
                };
            };
        };
    };
};

#endif