#include <sqltypes.h>
#include "core/string/string.h"
#include "core/custom/guid.h"

#if !defined(_CORE_DATABASE_INTERFACE_RECORDSET)
#define _CORE_DATABASE_INTERFACE_RECORDSET

namespace core
{
    namespace database
    {
        namespace interface
        {
            using namespace core::custom;

            class connection;

            class recordset
            {
                friend class connection;

            private:
                virtual bool create(void *source) = 0;

            public:
                virtual bool IsInitalised() = 0;

                virtual bool MoveNext() = 0;

                virtual long GetLong(long index) = 0;
                virtual string GetString(long index) = 0;
                virtual float GetFloat(long index) = 0;
                virtual double GetDouble(long index) = 0;
                virtual bool GetBool(long index) = 0;
                virtual TIMESTAMP_STRUCT GetTimeStamp(long index) = 0;
                virtual guid GetGUID(long index) = 0;

                virtual bool BindLong(long index, long &data) = 0;
                virtual bool BindString(long index, unsigned char *data) = 0;
                virtual bool BindFloat(long index, float &data) = 0;
                virtual bool BindDouble(long index, double &data) = 0;
                virtual bool BindBool(long index, bool &data) = 0;
                virtual bool BindTimeStamp(long index, TIMESTAMP_STRUCT &data) = 0;
                virtual bool BindGUID(long index, guid &data) = 0;

                virtual bool Execute() = 0;

                virtual void close() = 0;

            protected:
                virtual bool Execute(string sql) = 0;
                virtual bool Prepare(string sql) = 0;
            };
        };
    };
};

#endif