#include <math.h>
#include "core/math/xyzw.h"
#include "core/math/vector.h"
#include <tuple>

#ifndef _CORE_MATH_POINT
#define _CORE_MATH_POINT

namespace core
{
	namespace math
	{
		class point : public xyzw<float>
		{
		public:
			point(float x1 = 0.0f, float y1 = 0.0f, float z1 = 0.0f, float w1 = 0.0f) : xyzw(x1, y1, z1, w1) { }

			void reset() { x = y = z = w = 0.0f; }

			float distance(point &origin)
			{
				point length = origin - (*this);
				length = length * length;
				return sqrt(length.x + length.y + length.z);
			}

		public:
			bool operator==(const point& rhs) const
			{
				return std::tie(x,y,z,w) == 
						std::tie(rhs.x,rhs.y,rhs.z,rhs.w);
			}

		public:
			point operator=(const point &src) { copy((point&)src); return *this; }
			point operator+(const point &src) { return point(x + src.x, y + src.y, z + src.z); }
			point operator-(const point &src) { return point(x - src.x, y - src.y, z - src.z); }
			point operator*(const point &src) { return point(x * src.x, y * src.y, z * src.z); }

			point operator+(const vector &src) { return point(x + src.x, y + src.y, z + src.z); }
			point operator-(const vector &src) { return point(x - src.x, y - src.y, z - src.z); }
		};
	};
};

#endif