#include "net/stream/interface/in.h"

#ifndef _PARSER_INTERFACE_IN
#define _PARSER_INTERFACE_IN

namespace parser
{
    namespace interface
    {        
        template <class T> class in
        {
        public:
              virtual bool deserialize(T &object, net::stream::interface::in *source, unsigned long length) = 0;
        };
    };
};

#endif