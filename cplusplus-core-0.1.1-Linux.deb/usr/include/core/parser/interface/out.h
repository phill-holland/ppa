#include "net/stream/interface/out.h"

#ifndef _PARSER_INTERFACE_OUT
#define _PARSER_INTERFACE_OUT

namespace parser
{
    namespace interface
    {        
        template <class T> class out
        {
        public:              
              virtual unsigned long prepare(T &object) = 0;
		      virtual bool serialize(net::stream::interface::out *destination) = 0;
        };
    };
};

#endif