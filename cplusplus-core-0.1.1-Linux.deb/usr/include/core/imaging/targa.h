#include "core/string/string.h"
#include "core/imaging/texture.h"
#include "core/imaging/colour.h"

#ifndef _CORE_IMAGING_TARGA
#define _CORE_IMAGING_TARGA

namespace core
{
	namespace imaging
	{
		namespace targa
		{
			class header
			{
			public:
				unsigned char offset;
				unsigned char colour_type;
				unsigned char image_type;
				unsigned char colour_map[5];
				unsigned short x_origin, y_origin;
				unsigned short width, height;
				unsigned char bpp;
				unsigned char description;
			};

			class targa
			{
			protected:
				texture *source;

			protected:		
				static const unsigned long TGA_RGB = 2UL;
				
			public:
				targa(texture *src) { source = src; }
				
				bool load(string &filename);
				bool save(string &filename);

				bool load(const char *filename);
				bool save(const char *filename);
			};
		};
	};
};

#endif