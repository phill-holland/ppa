#include "core/string/string.h"
#include <uuid/uuid.h>

#if !defined(_CORE_CUSTOM_GUID)
#define _CORE_CUSTOM_GUID

namespace core
{
	namespace custom
	{
		class guid
		{
			uuid_t value;
			bool init;

		public:
			guid() { reset(); }
			guid(const guid &unique) { init = true; }
			guid(const string &source);

			void clear() { reset(); }

			bool initalised() { return init; }
			void reset();

			string get();
			void generate() { reset(); }

		public:
			operator string() { return get(); }
		};
	};
};

#endif