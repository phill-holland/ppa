#include <mutex>

#ifndef _CORE_THREADING_MUTEX
#define _CORE_THREADING_MUTEX

namespace core
{
	namespace threading
	{
		class mutex : public std::lock_guard<std::mutex>
		{
		public:
			class token : public std::mutex
			{
			public:
				token() { }
				token(const token &source) { }
			};

		public:
			mutex(token &t) : std::lock_guard<std::mutex>(t) { }
		};
	};
};

#endif