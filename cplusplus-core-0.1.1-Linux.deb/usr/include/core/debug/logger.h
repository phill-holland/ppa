#include "core/threading/semaphore.h"
#include "core/threading/thread.h"
#include "core/string/string.h"
#include <stdio.h>
#include <iostream>
#include <fstream>

#ifndef _CORE_DEBUG_LOGGER
#define _CORE_DEBUG_LOGGER

namespace core
{
	namespace debug
	{
		class logger
		{
			static long constructed;
			static std::ofstream handle;

			static const long size = 25L;
			static const long buffer = 2048L;

			core::threading::semaphore::token token;

		public:

			logger();
			logger(char *destination);
			~logger() { if(constructed==-1L) handle.close(); --constructed; }

			void add(char *line);
			void add(unsigned char *line);
			void add(float number);
			void add(long number);
			void add(int number);
			void add(bool value);
			void add_hex(long number);
			void add(string &line);

		private:
			void reset(const char *filename);
			void write(const char *line);

		public:
			logger operator<<(char *line) { add(line); return logger(); }
			logger operator<<(unsigned char *line) { add(line); return logger(); }
			logger operator<<(float number) { add(number); return logger(); }
			logger operator<<(double number) { add((float)number); return logger(); }
			logger operator<<(int number) { add(number); return logger(); }
			logger operator<<(long number) { add(number); return logger(); }
			logger operator<<(unsigned long number) { long temp = (long)number; add(temp); return logger(); }
			logger operator<<(bool value) { add(value); return logger(); }
			logger operator<<(string line) { add(line); return logger(); }

			logger operator>>(char *line) { add(line); return logger(); }
			logger operator>>(unsigned char *line) { add(line); return logger(); }
			logger operator>>(float number) { add(number); return logger(); }
			logger operator>>(double number) { add((float)number); return logger(); }
			logger operator>>(int number) { add(number); return logger(); }
			logger operator>>(long number) { add(number); return logger(); }
			logger operator>>(unsigned long number) { long temp = (long)number; add(temp); return logger(); }
			logger operator>>(bool value) { add(value); return logger(); }
			logger operator>>(string line) { add(line); return logger(); }

		protected:
			void floatToStr(char *temp, float number);
			void intToStr(char *temp, int number);
			void longToStr(char *temp, long number);
			void longHexToStr(char *temp, long number);
			void boolToStr(char *temp, bool value);
		};
	};
};

extern core::debug::logger Log;

#endif

