#include "core/queue/interface/features.h"
#include "core/string/string.h"

#ifndef _CORE_QUEUE_STACK
#define _CORE_QUEUE_STACK

namespace core
{
	namespace stack
	{
		template <class X> class stack : public core::queue::interface::features::fifo::bidirectional<X>
		{	
			bool init;
			X **items;

			long elements,totalInStack;

		public:
			stack(long total) { makeNull(); reset(total); }
			stack() { makeNull(); reset(15L); }
			~stack() { cleanup(); }
			bool initalised() { return init; }
			void reset(long total);

			unsigned long entries() { return elements; }

			bool isfull() { if(elements>=totalInStack-1L) return true; return false; }
			bool isempty() { if(elements<=0L) return true;  return false; }

			void empty() { elements = 0L; }

			void push(X *item);	
			bool pop(X &item);

			bool get(X &destination) { return pop(destination); }

			bool set(X &source) { push(&source); return true; }

			string identifier() { return string("stack"); }

		private:
			void cleanup() 
			{ 
				if(items!=NULL) 
				{		
					for(long i=0L;i<totalInStack;++i)
					{
						if(items[i]!=NULL) delete items[i];
					}
					delete[] items;
				}		
			}

			void makeNull()
			{	
				items = NULL;
			}
		};

		template <class X> void stack<X>::reset(long total)
		{
			cleanup(); elements = 0L;

			init = false;
			totalInStack = total;

			items = new X *[total];
			if(items==NULL) return;
			for (long i = 0L; i < total; ++i) items[i] = NULL;

			for(long i=0L;i<total;++i)
			{
				items[i] = new X();
				if(items[i] == NULL) return;
			}

			init = true;
		}

		template <class X> inline void stack<X>::push(X *item)
		{
			*items[elements] = *item;	
			++elements;
		}

		template <class X> inline bool stack<X>::pop(X &item)
		{
			if(elements>0L)
			{
				--elements;
				item = *items[elements];
				return true;
			}	
			return false;
		}
	};
};

#endif
