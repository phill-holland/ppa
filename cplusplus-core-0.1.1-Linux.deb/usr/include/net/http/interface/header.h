#include "net/http/parameter.h"
#include "net/stream/interface/in.h"
#include <vector>

#ifndef _NET_HTTP_INTERFACE_HEADER
#define _NET_HTTP_INTERFACE_HEADER

namespace net
{
	namespace http
	{
		namespace interface
		{			
			class header
			{
			public:
				std::vector<parameter> parameters;

			public:
				header() { reset(); }

			public:
				void reset()
				{
					parameters.clear();
				}

				bool isChunked();
				bool isJson();
				bool isBinary();
				
			public:
				bool decode(const string &value);
			
			public:
				virtual void clear() = 0;
				virtual bool isempty() = 0;
				virtual int extract(const string &value) = 0;
			};

			class client
			{
			public:
				bool decode(::net::http::interface::header *header, ::net::stream::interface::in *source);
			};			
		};
	};
};

#endif