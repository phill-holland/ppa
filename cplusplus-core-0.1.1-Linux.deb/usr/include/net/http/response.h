#include "net/http/interface/header.h"
#include "net/stream/interface/in.h"
#include "net/stream/interface/out.h"
#include "core/string/string.h"

#ifndef _NET_HTTP_RESPONSE
#define _NET_HTTP_RESPONSE

namespace net
{
	namespace http
	{
		namespace response
		{
			class header : public ::net::http::interface::header
			{
			public:
				string protocol;
				string status;

			public:
				header() : ::net::http::interface::header() 
				{ 
					clear(); 
				}

			public:
				void clear();

				bool isempty();
				long getStatus();

			public:
				bool decode(const string &value);

			public:
				string response(int status);

			protected:
				int extract(const string &value);
			};

			class client : public ::net::http::interface::client
			{
			public:
				header head;

			public:
				client() { clear(); }

			public:
				void clear() { head.clear(); }
				
				bool decode(::net::stream::interface::in *source)
				{
					return ::net::http::interface::client::decode(&head, source) && !head.isempty();
				}				

				bool response(int status, ::net::stream::interface::out *destination);
			};
		};
	};
};

#endif