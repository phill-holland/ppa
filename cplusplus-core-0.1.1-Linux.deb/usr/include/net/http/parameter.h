#include "core/string/string.h"

#ifndef _NET_HTTP_PARAMETER
#define _NET_HTTP_PARAMETER

namespace net
{
    namespace http
    {	
        class parameter
        {
        public:
            string name;
            string value;
        
        public:
            parameter() { clear(); }
            parameter(string _name, string _value) { name = _name; value = _value; }

        public:
            void clear()
            {
                name.clear();
                value.clear();
            }

            bool valid()
            {
                return ((name.length() > 0) && (value.length() > 0));
            }

            bool decode(const string &value);
            string encode();
        };
    };
};

#endif