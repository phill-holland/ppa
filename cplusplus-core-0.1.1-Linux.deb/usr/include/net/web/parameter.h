#include "core/string/string.h"

#ifndef _NET_WEB_PARAMETER
#define _NET_WEB_PARAMETER

namespace net
{
	namespace web
	{
		class parameter
		{
		public:
			string name;
			string value;

		public:
			parameter(string name = "", string value = "")
			{
				this->name = name;
				this->value = value;
			}
			parameter(parameter const &source) { copy(source); }

			void copy(parameter const &source);

		public:
			parameter& operator=(const parameter& source)
			{
				this->copy((parameter&)source);
				return *this;
			}
		};
	};
};

#endif