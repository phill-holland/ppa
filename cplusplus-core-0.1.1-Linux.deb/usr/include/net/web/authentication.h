#include "core/string/string.h"

#ifndef _NET_WEB_AUTHENTICATION
#define _NET_WEB_AUTHENTICATION

namespace net
{
	namespace web
	{
		class authentication
		{
		public:
			bool required;
			string username, password;

		public:
			authentication() { reset(); }

			void reset();
		};
	};
};

#endif