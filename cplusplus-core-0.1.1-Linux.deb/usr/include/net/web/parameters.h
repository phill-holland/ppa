#include "core/string/comparison.h"
#include "parameter.h"
#include <vector>
#include <unordered_map>

#ifndef _NET_WEB_PARAMETERS
#define _NET_WEB_PARAMETERS

namespace net
{
	namespace web
	{
		using namespace comparison;

		class parameters
		{
			static const unsigned long MAX = 15L;

		private:
			web::parameter **headers;
			std::unordered_map<string, int, hasher, equality> map;

			unsigned long length;

			bool init;

		public:
			parameters() { makeNull(); reset(); }
			~parameters() { cleanup(); }

			bool initalised() { return init; }
			void reset();

			void clear();

			bool add(parameter source);

			bool exists(string name);

			parameter& get(unsigned long index);
			string get(string name);

			long count();

		public:
			parameter& operator[](int index)
			{
				return get((unsigned long)index);
			}

		protected:
			void makeNull();
			void cleanup();
		};
	};
};

#endif