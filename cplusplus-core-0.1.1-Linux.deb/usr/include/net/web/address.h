#include "core/string/string.h"

#ifndef _NET_WEB_ADDRESS
#define _NET_WEB_ADDRESS

namespace net
{
	namespace web
	{
		class address
		{
		public:
			string server;
			string path;

			bool secure;

			long port;

		public:
			address() { reset(); }
			address(string &url) { reset(); get(url); }

			void reset();
			bool get(string &url);
		};
	};
};

#endif