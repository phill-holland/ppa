#include "net/stream/interface/out.h"
#include "core/string/string.h"
#include <iostream>
#include <fstream>

#ifndef _NET_STREAM_WFSTREAM_OUT
#define _NET_STREAM_WFSTREAM_OUT

namespace net
{
    namespace stream
    {
        namespace wfstream
        {
            namespace out
            {
                class wfstream : public net::stream::interface::out
                {
                    std::ofstream handle;
                    string buffer;
                    bool init;

                public:
                    wfstream(string filename) { makeNull(); reset(filename); }
                    ~wfstream() { cleanup(); }

                    bool initalised() { return init; }
                    void reset(string filename);

                    int write(string data);
                    bool flush();
                    void clear();
                    bool terminate() { return true; }
                    
                protected:
                    bool open(string filename);
                    void close();

                protected:
                    void makeNull() { }
                    void cleanup() { close(); }
                };
            };
        };
    };
};

#endif
