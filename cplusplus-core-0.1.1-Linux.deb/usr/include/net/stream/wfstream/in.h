#include "net/stream/interface/in.h"
#include "core/string/string.h"
#include <iostream>
#include <fstream>

#ifndef _NET_STREAM_WFSTREAM_IN
#define _NET_STREAM_WFSTREAM_IN

namespace net
{
    namespace stream
    {
        namespace wfstream
        {
            namespace in
            {
                class wfstream : public net::stream::interface::in
                {
                    const static int LENGTH = 1000l;

                    std::ifstream handle;

                    char buffer[LENGTH];
                    int index, length;

                    bool init;

                public:
                    wfstream(string filename) { makeNull(); reset(filename); }
                    ~wfstream() { cleanup(); }

                    bool initalised() { return init; }
                    void reset(string filename);

                    bool read(char &destination);
                    bool next();
                    bool fetch();
                    void clear();
                    bool terminate() { return true; }

                protected:
                    bool open(string filename);
                    void close();

                protected:
                    void makeNull() { }
                    void cleanup() { close(); }
                };
            };
        };
    };
};

#endif
