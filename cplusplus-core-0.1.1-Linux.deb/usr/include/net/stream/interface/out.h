#include "core/string/string.h"

#ifndef _HET_HTTP_STREAM_INTERFACE_OUT
#define _HET_HTTP_STREAM_INTERFACE_OUT

namespace net
{
	namespace stream
	{
		namespace interface
		{
			class out
			{
			public:
				virtual int write(string data) = 0;
				virtual bool flush() = 0;
				virtual void clear() = 0;
				virtual bool terminate() = 0;
			};
		};
	};
};

#endif