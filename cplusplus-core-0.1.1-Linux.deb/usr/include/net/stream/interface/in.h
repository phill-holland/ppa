#include "core/string/string.h"

#ifndef _HET_HTTP_STREAM_INTERFACE_IN
#define _HET_HTTP_STREAM_INTERFACE_IN

namespace net
{
	namespace stream
	{
		namespace interface
		{
			class in
			{
			public:
				virtual bool read(char &destination) = 0;
				virtual bool next() = 0;
				virtual bool fetch() = 0;
				virtual void clear() = 0;		
				virtual bool terminate() = 0;		
			};
		};
	};
};

#endif