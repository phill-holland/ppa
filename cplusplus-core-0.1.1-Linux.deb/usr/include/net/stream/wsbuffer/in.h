#include "net/socket/interface/socket.h"
#include "net/socket/interface/client.h"
#include "net/stream/interface/in.h"
#include "core/threading/semaphore.h"
#include "core/debug/logger.h"

#ifndef _NET_STREAM_WSBUFFER_IN
#define _NET_STREAM_WSBUFFER_IN

namespace net
{
    namespace stream
    {
        namespace wsbuffer
        {
            class in : public net::stream::interface::in
            {
                static const long LENGTH = 10000L;

            private:                
                char *buffer;
                long index, readptr;
                long length;
            
                net::socket::interface::client *client;

                core::threading::semaphore::token token;

                bool init;

            public:
                in(net::socket::interface::client *source, long length = LENGTH) { makeNull(); reset(source, length); }
                ~in() { cleanup(); }

                bool initalised() { return init; }
                void reset(net::socket::interface::client *source, long length);

                bool read(char &destination);
                bool next();
                bool fetch();

                void clear()
                {
                    core::threading::semaphore lock(token);

                    index = 0L; readptr = 0L;
                }

                bool terminate() { return true; }

            protected:
                bool receive();

            protected:
                void makeNull()
                {
                    buffer = NULL;
                }

                void cleanup()
                {
                    if(buffer != NULL) delete[] buffer;
                }
            };
        };
    };
};

#endif