#include "net/stream/interface/out.h"
#include "core/parser/interface/out.h"
#include "core/string/string.h"
#include "core/debug/logger.h"
#include <fmt/format.h>

#ifndef _NET_STREAM_WSCHUNK_OUT
#define _NET_STREAM_WSCHUNK_OUT

namespace net
{
    namespace stream
    {
        namespace wschunk
        {
            template <class T> class out
            {
                net::stream::interface::out *destination;
                parser::interface::out<T> *serialiser;

            public:
                out(net::stream::interface::out *destination, parser::interface::out<T> *serialiser) 
                { 
                    this->destination = destination;
                    this->serialiser = serialiser;
                }

                bool transmit(T &object)
                {
                    unsigned long length = serialiser->prepare(object);
                    string temp = fmt::format("{:x}", length); 
                    temp.concat(string("\r\n"));

                    if(destination->write(temp) != temp.length()) return false;

                    if (!serialiser->serialize(destination)) return false;

                    string end_temp("\r\n");
                    if(destination->write(end_temp) != end_temp.length()) return false;

                    return destination->flush();
                }

                bool terminate()
                {                    
                    string data("0\r\n\r\n");
                    if(destination->write(data) == data.length())
                    {                             
                        return destination->flush();
                    }

                    return false;
                }
            };
        };        
    };
};

#endif