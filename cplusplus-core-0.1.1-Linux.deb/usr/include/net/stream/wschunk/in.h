#include "net/stream/interface/in.h"
#include "core/parser/interface/in.h"
#include "core/debug/logger.h"

#ifndef _NET_STREAM_WSCHUNK_IN
#define _NET_STREAM_WSCHUNK_IN

namespace net
{
    namespace stream
    {
        namespace wschunk
        {
            template <class T> class in
            {
                net::stream::interface::in *source;
                parser::interface::in<T> *deserialiser;

            public:
                in(net::stream::interface::in *source, parser::interface::in<T> *deserialiser) 
                { 
                    this->source = source;
                    this->deserialiser = deserialiser;
                }

                bool receive(T &object)
                {
                    int state = 0; string temp;
                    bool result = false;

                    char t;

                    do
                    {                      
                        if(source->read(t))
                        {
                            if(((t==13)||(t==10))&&(temp.length()==0)) { }
                            else if((t==13)&&(state==0)) ++state;
                            else if((t==10)&&(state==1)) ++state;

                            else temp += t;
                        }
                        result = source->next();

                    } while((result)&&(state <= 1));
                    
                    if((state >= 2)&&(temp.length() > 0))
                    {          
                        unsigned long bytes_to_read = (unsigned long)std::stoul(temp, nullptr, 16);  
                        if(bytes_to_read > 0L)
                        {
                            result = deserialiser->deserialize(object, source, bytes_to_read);
                        }
                    }
                    
                    return result;
                }

                bool terminate()
                {
                    bool result = false;
                    string temp;
                    int state = 0;
                    char t;

                    do
                    { 
                        if(source->read(t))
                        {
                            if(((t==13)||(t==10))&&(temp.length()==0)) { }
                            else if((t==13)&&(state==0)) ++state;
                            else if((t==10)&&(state==1)) ++state;
                            else if((t==13)&&(state==2)) ++state;
                            else if((t==10)&&(state==3)) ++state;
                            else temp += t;
                        }
                        result = source->next();

                    } while((result)&&(state <= 3));

                    if((state >= 4)&&(temp.length() > 0))
                    {
                        int value = (long)std::stoul(temp, nullptr, 16);
                        if(value == 0L) return true;
                    }

                    return false;
                }
            };
        };
    };
};

#endif