#ifndef _HET_HTTP_SOCKET_INTERFACE_SERVER
#define _HET_HTTP_SOCKET_INTERFACE_SERVER

namespace net
{
    namespace socket
    {
        namespace interface
        {
            class server
            {
            public:
                virtual bool open(long port) = 0;
                virtual bool isopen() = 0;
                virtual void close() = 0;
            };
        };
    };
};

#endif