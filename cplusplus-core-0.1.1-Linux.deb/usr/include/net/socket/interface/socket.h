#include "core/string/string.h"
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#ifndef _NET_HTTP_SOCKET_INTERFACE_SOCKET
#define _NET_HTTP_SOCKET_INTERFACE_SOCKET

namespace net
{
    namespace socket
    {
        namespace interface
		{
			class socket
			{
			protected:
				const static long IPV4_LEN = 16L;
				const static long IPV6_LEN = 46L;

			public:
				socket() { }
				~socket() { }

				struct addrinfo *getHostByName(string &server);
			};
		};
	};
};

#endif