#include "net/socket/interface/socket.h"
#include "net/socket/interface/client.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include "core/string/string.h"

#ifndef _NET_SOCKET_CLIENT
#define _NET_SOCKET_CLIENT

namespace net
{
    namespace socket
    {
        class client : public interface::socket, public interface::client
        {
            const static int timeout;

        private:
            friend class server;

        protected:
            int _socket;

        public:
            client() : interface::socket() { _socket = -1; }

            bool open(string &source, long port);
            bool isopen() { return _socket != -1; }

            int read(char *buffer, int length, int flags);

            int write(string &data, int flags);
            int write(const char *buffer, int length, int flags);

            void close();
        };
    };
};

#endif