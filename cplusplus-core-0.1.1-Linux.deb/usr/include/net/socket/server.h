#include "net/socket/interface/socket.h"
#include "net/socket/interface/server.h"
#include "net/socket/client.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include "core/string/string.h"

#ifndef _NET_SOCKET_SERVER
#define _NET_SOCKET_SERVER

namespace net
{
    namespace socket
    {
		class server : public interface::socket, public interface::server
		{
		protected:
			int _socket;
			const static int timeout;

		public:
			server() : socket() { _socket = -1; }
			~server() { close(); }

			bool open(long port);
			bool isopen() { return _socket != -1; }

			bool wait(client &destination);

			void close();
		};
	};
};

#endif
